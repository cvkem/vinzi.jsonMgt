/*
	This is used to load all the plugins scripts and other dependancies
*/

$.getScript("../cdm/js/Query_cdp_included.js");
$.getScript("../cdm/js/vUtil.js");
$.getScript("../cdm/js/cdm.js");
$.getScript("../cdm/js/glueCdm.js");