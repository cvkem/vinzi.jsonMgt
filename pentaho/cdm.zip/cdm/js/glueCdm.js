/*
  Merge CDM interface on CDE client
*/

//var getDashboardFilename = cdfdd.dashboardData.filename.substring(1);

var cdmMessage;

var theCdpFile = function (){
    // Look at the current Dashboards.context and derive the name of the
    // corresponding .cdp.xml file. The file is in the same directory/folder as
    // the dashboard and uses an identical base-name.
    var theSolution = 'system';
    var thePath = 'cdm';
    var theFile = 'cdm.cdp.xml';

    // set global with path parameters
    theCdpFileParams = {solution: theSolution,
        path: thePath,
        file: theFile};
    // make string-path
    var pars = ["solution="+theSolution,
                "path="+thePath,  
                "file="+theFile
                ];
    return pars.join("&");
}();




var showingPulldown = false;

var showPulldown = function(){
  
  var $cdmDropDownButton = $("#cdmDropDown");

  if(!showingPulldown){
        showingPulldown = true;
    
        var $ul = $("<ul id='cdmOptions' class='controlOptions' style='z-index: 10;'></ul>");
        $cdmDropDownButton.append($ul);
        var $cdmOptions = $("#cdmOptions");

        var $createTrack = $("<li class='item' id='createTrack'>Create Track</li>");
        $createTrack.click(function(event){run_action_src ('create');});
        $cdmOptions.append($createTrack);

        var $commitTrack = $("<li id='commitButton' class='item popupIcon'>Commit Track</li>");
        $commitTrack.click(function(event){
            $ul.children().remove();
            var content = "<h2>Commit</h2><hr/><span class='title'>Track:<p/><span class='description'>"+cdfdd.dashboardData.filename.substring(1)+"</span></span><span class='title'><form><fieldset><label for='msg'>Commit message:</label><br><textarea type='text' name='msgTxt' id='msgTxt' style='width: 400px;'></textarea></br></fieldset></form></span>";

            $.prompt(content,{
                buttons:{
                    Commit:1,
                    Cancel:2
                },
                prefix: "popup",
                submit: function(v,m,f){
                    if(v==1){
                        if($("#msgTxt").val().length>0){
                            run_action_full("commit",cdfdd.dashboardData.filename.substring(1),"",$("#msgTxt").val());
                            return true;
                        }else{
                            $.prompt("<span class='title'>Error:</span><span class='description'>Please insert a commit message first!</span>");
                            return false;
                        }
                    }else if(v==2){
                        return true;
                    }
                }
            });

        });
        $cdmOptions.append($commitTrack);

        var $diff = $("<li class='item' id='differences'>Differences</li>");
        $diff.click(function(event){
            run_action_src('diff');
            //getDifferences() ;
        });
        $cdmOptions.append($diff);
        
        var $revert = $("<li class='item' id='revert'>Revert to Commit</li>");
        $revert.click(function(event){
            run_action_full('revert-to-commit',cdfdd.dashboardData.filename.substring(1),cdfdd.dashboardData.filename.substring(1),"");
            $.ajax({
                url: "http://localhost:8080/pentaho/Publish?publish=now&class=org.pentaho.platform.engine.services.solution.SolutionPublisher",
                success: function(){cdfdd.reload();}
            });
        });
        $cdmOptions.append($revert);

        var $dropLast = $("<li class='item' id='drop' style='border-bottom: 1px #12a2d8 solid'>Drop last Commit</li>");
        $dropLast.click(function(event){run_action_src('drop-last-commit');});
        $cdmOptions.append($dropLast);

        var $duplicate = $("<li class='item popupIcon' id='duplicate'>Duplicate track</li>");
        $duplicate.click(function(event){
            $ul.children().remove();
            this.innerText = "";
            var content = "<h2>Duplicate Track</h2><hr><span class='description'>Place the destination without the extension '.cdfde'<span><hr/><span class='title'><form><fieldset><label for='dst'>Destination: </label><p/><input type='text' name='dst' id='dst' style='width:100%;'></fieldset></form></span>";
            $.prompt(content,{
                prefix: "popup",
                buttons:{
                    Duplicate:1,
                    Cancel:2
                },
                submit: function(v,m,f){
                    if(v==1){
                        if($("#dst").val().length>0){
                            run_action_full("clean-copy",cdfdd.dashboardData.filename.substring(1));
                            $.ajax({
                                url: "http://localhost:8080/pentaho/Publish?publish=now&class=org.pentaho.platform.engine.services.solution.SolutionPublisher",
                                success: function(){cdfdd.reload();}
                            });
                        }else{
                            $.prompt("<h2>Error!</h2><span class='description'>Please insert a destination!</span>",{prefix: "popup"});
                            return false;
                        }
                    }else if(v==2){
                        return true;
                    }
                }
            });
            
        });
        $cdmOptions.append($duplicate);

                

        var $applyChanges = $("<li class='item popupIcon' id='apply'>Apply changes</li>");
        $applyChanges.click(function(event){

            var fldr;
            var fl;

            $ul.children().remove();
            this.innerText = "";
            var content = "<h2>Apply Changes</h2><hr/><form id='applyForm'><fieldset><input type='hidden' name='dst' id='dst' readonly style='width:100%;'><li style='list-style: none;'><label for='depth'>Depth(0 = last commit): </label><p/><input type='text' name='depth' id='depth' value='0' style='width:400px;'></li></fieldset><div id='applyFileTree'></div></form>";
            $.prompt(content,
                {
                    buttons: {
                        Ok: 1 ,
                        Browse: 2,
                        Cancel: 3
                    },
                    focus: 1,
                    prefix: "popup",
                    submit: function(v,m,f){
                        if(v==1){
                            if($("#dst").val().length>0){
                                run_action_full('apply',cdfdd.dashboardData.filename.substring(1),$("#dst").val(),parseInt($("#depth").val()));
                                $("#applyFileTree").remove();
                                return true;
                            }else{
                                $.prompt("<span class='title'>Error:</span><span class='description'>Please select a file first!</span>");
                                return false;
                            }
                        }else if(v==2){
                            focus = 1;
                            if($("#applyFileTree").is(':empty')){
                                $("#applyFileTree").fileTree({
                                    root: '/',
                                    script: CDFDDDataUrl.replace("Syncronize","ExploreFolder?fileExtensions=.cdfde&access=create"),
                                    expandSpeed: 1000,
                                    collapseSpeed: 1000,
                                    multiFolder: false,
                                    folderClick:
                                              function(obj,folder){
                                                fldr = folder.substring(1);
                                                $("#dst").val(fldr);
                                              }

                                },
                                function(file){
                                    fl = file.substring(1); 
                                    $("#dst").val(fl);
                                });


                            }else if(!$("#applyFileTree").is(':visible')){
                                $("#applyFileTree").show();
                            }else if($("#applyFileTree").is(':visible')){
                                //$("#applyFileTree").fileTree('show');
                                $("#applyFileTree").hide();
                            }
                            return false;

                        }else if(v==3){
                            return true;
                        }
                    }
                })

        });
        $cdmOptions.append($applyChanges);

        var $dirty = $("<li class='item'>Show dirty</li>");
        $dirty.click(function(event){run_action_src("dirty","*");});
        $cdmOptions.append($dirty);


        var $checkout = $("<li class='item' id='checkout'>Checkout copy</li>");
        $checkout.click(function(event){
            run_action_src('checkout-copy-last');
            $.ajax({
                url: "http://localhost:8080/pentaho/Publish?publish=now&class=org.pentaho.platform.engine.services.solution.SolutionPublisher",
            });
        });
        $cdmOptions.append($checkout);


        var $help = $("<li class='item popupIcon separator'>Help</li>");
        $help.click(function(event){
            $ul.children().remove();
            this.innerText = "";

            var content = "<h2>Help</h2><hr/><span class='title'>"+helpFuncAll()+"</span>"
            $.prompt(content,{prefix:"popup"})
        });
        $cdmOptions.append($help);



        var divWidth = $('#header').width();
        var leftSpace = (150-divWidth)/2;
        $ul.css({'display':'block', 'width':'170px', 'left':-leftSpace});
        $ul.addClass('linkActive');



  }else{
    showingPulldown = false;
    var $cdmOptions = $("#cdmOptions");
    $cdmOptions.remove();
    cdmDropDown.removeClass("linkActive");
  }

}


var grayOutElement = function(elementID){

    $b = $("#"+elementID);
        $b.css("background","#444");
        $b.css("color","#000");
        $b.css("cursor","default");
        $b.unbind();
}
//This function checks each action if they can be preformed at that time. If not, they won't be shown.
var checkAvailableActions = function(){

    //Checks if there is already a track associated with the dashboard
    var message = run_action_trackExists(cdfdd.dashboardData.filename.substring(1)).toString();
    //alert(message);
    var $b;
    if(message=='true'){
        grayOutElement("createTrack")
    }else{
        grayOutElement("duplicate");
        grayOutElement("differences");
        grayOutElement("commitButton");
        grayOutElement("apply");
        grayOutElement("revert");
        grayOutElement("drop");
        grayOutElement("checkout");
        
    }

    //This one checks if there are changes on the dashboard and if there are NONE it then proceeds to disable commit, and diff button!
    message = run_action_getResponse('diff').toString();
    if(message.indexOf("--- NONE ---")>-1){
        grayOutElement("differences");
        grayOutElement("commitButton");
        grayOutElement("revert")
    }



}


var header= $("#headerLinks");
var cdmDropDown = $("<a class='headerButton' id ='cdmDropDown' href='#' style='top: 5px;margin-left: 5px;'>Version Control<div class='buttonImage'></div></a>");


cdmDropDown.click(function(event){
    event.stopPropagation();
    cdmDropDown.addClass("linkActive");
    showPulldown();
    controlOptionsRepositioning();
    if(showingPulldown==true){
        checkAvailableActions();
    }
});

header.append(cdmDropDown);

$('body').click(function(event){
    if(showingPulldown==true){
        showPulldown();
        cdmDropDown.removeClass("linkActive");
    }
});

$(document).ready(function(){
    cdfdd.save();
});
