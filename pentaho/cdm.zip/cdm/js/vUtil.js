/**
   vUtil.js
	Set of utility functions to use in javascript, for logging etc.
   
   copyright Vinzi BV  2011-2012.
   License: Eclipse Public License (see: http://www.eclipse.org/legal/epl-v10.html)
**/



/**
Some logging and debugging aids for JS.
Also contains a simple fix to handle the fact that IE-7 does not have a console object when debugging is turned of
(however, more generic fixes are available).
**/

function showError(prefix, err) {
  var msg = prefix + '\n\n';
  if (typeof err.message != 'undefined')
     msg += err.message + '\n\n';
  msg += strObj(err);

  return msg;
}



// show the message on the console. If the console does not exist it
// will be appended to body (to prevent loss)
function vWarn(msg) {
    if ((typeof console == 'undefined') ||
        (typeof console.log == 'undefined')) {
        // create a vinzi_console for internal usage and log to it
        var target = $('body #vinzi_warn');
        if (target.length === 0)
            target = $('<div id="vinzi_warn"></div>').appendTo('body');
        target.append(strObj(msg)+'<br/>');
    } else
        console.log(msg);
}

function vError(msg) {
    // issue an warning AND show the alert.
    vWarn(msg);

    
    var $ul = $("#cdmOptions");
    $ul.hide();
    var content = "<h2>Error!</h2><hr/><span class='title'>Details:</span><span class='description'>"+msg+"</span>";
    $.prompt(content.replace(/\n/,"<br/>"),{prefix: "popup"});
    

}

// show the message on the console. If the console does not exist it
// the staced in a HIDDEN div (don't bother the user)
function vTrace(msg) {
    if ((typeof console == 'undefined') ||
        (typeof console.log == 'undefined')) {
        // create a vinzi_console for internal usage and log to it
        var target = $('body #vinzi_trace');
        if (target.length === 0)
            target = $('<div id="vinzi_trace"></div>')
		.appendTo('body').hide();
        target.append(strObj(msg)+'<br/>');
    } else
        console.log(msg);
}



/**
 * functions to stringify things and to make them printable/usable in html, etc..
**/


function strObj(obj) {
  if ((typeof obj == 'string') || 
      (typeof obj == 'number') || 
      (typeof obj == 'boolean'))
    return ''+obj;
  var s = '';
  for (var x in obj) {
    if (obj.hasOwnProperty(x))
       s += x+':'+obj[x]+';\n';
  }
  return s;
}


function stripNonAscii (s) {
	// strips non-ascii characters by replacing them with a _ (recursive implementation).
    if (s == null)  // sentinel for null-values
      return '';
    //var t = (/[(\x20-\x7F)]*/g).exec(s)[0];
    var t = (/[\w\d]*/g).exec(s);
    if (t == null)  // first character is non-ascii
	return '_'+stripNonAscii(s.slice(1));

    t =  (t)? t[0] : t;
    if (t.length == s.length)
	return t;
    else
	return t+'_'+stripNonAscii(s.slice(t.length+1));
};


function trimSlash (s) {
    var last = s.length - 1;
    last = (s[last] == '/') ? last : last+1;
    var first = (s[0] == '/') ? 1 : 0;
    return s.substr(first, last); };


    /**
     *  CDA-data transformation.
    **/



  function getRowAsObj(tbl) {
    	// Turn a row of a cda-dataset into a hash-map
        var params = {};
        var md = tbl.rawData.metadata;
        var row = tbl.tableData[ tbl.rowIdx ];
        
        for(var i=0; i<md.length; i++) {
            var lbl = md[i].colName;
            var idx = md[i].colIndex;
            params[lbl] = row[ idx ];
        }
        
        return params;
    };



/**
 * helper-function regarding users
**/


function isTestUser() {
    var user = Dashboards.context.user.toLowerCase();
    return ((user == 'joe') || (user == 'vinzi'));
}


function getCurrentUser() {
    var user ;//= arguments[0];
    user = "CDE"
    //var prefix = user.slice(0,4);
    //if ((prefix == prefix.toUpperCase()) && (prefix[3] == '-'))
        //user = user.slice(4);
    return user;
}
 


/**
 * Date related helper-function
**/

function parseIntSafe(s) {
 // the default parseInt parses radix-8 when the number is prefixed by a 0
 //  (this is deprecated behaviour, so do not rely on it
 //  This function forces the radix to 10
 return parseInt(s, 10);
};


function getNowDateItems() {
  var now = new Date();
  var year = now.getFullYear();
  var month = (now.getMonth()+1);
  var day  = now.getDate();   // now.getDay() returns the day-of-week  (instead of day of month)
  return {year: year,
          month: month,
          day: day };
};

function parseDbDate(s) {
    var pat = /([0-9]*)-([0-9]*)-([0-9]*)/;
    var items = pat.exec(s);
    if (items.length != 4)
       alert('WARN: could not parse database data: '+s+'\n\t obtained: '+items);
    return {year: parseIntSafe(items[1]),
            month: parseIntSafe(items[2]),
            day: parseIntSafe(items[3])  };
};

function addDateStrs (d) {
  d.monthStr = (d.month < 10) ? '0'+d.month : ''+d.month;
  d.dayStr = (d.day < 10) ? '0'+d.day : ''+d.day;
  d.yearStr = ''+d.year;
  d.displayStr = d.dayStr + '-' + d.monthStr + '-' + d.yearStr;
  d.dbStr = d.yearStr + '-' + d.monthStr + '-'+ d.dayStr;
  return d;
};

function parseDisplayDate(s) {
  var items = s.split('-');
  if (items.length != 3) {
     alert('FOUTMELDING: De datum dient opgegeven te worden als dd-mm-jj');
     return getNowDateItems;
  }
  items = items.map(function(s) {return parseIntSafe(s);});
  var year = items[2];
  year = (year < 100) ? year+2000: year;
  return {year:  year,
          month: items[1],
          day:   items[0]};
};


function clearCdaCache() {
    var base = '/pentaho/content/cda/clearCache';
    $.post(base);
    return;
};


/*
 *  Error showing dialog.
 */

$(function() {
    // this code assumes a dialogs div exists
	// create the default div for errors, if it does not exist yet
	if ($('#errorWindow').length == 0) {
		var dialogs = $('#cdmOptions');
		if (dialogs.length == 0)
			// silently ignore this error in CDM
			Dashboards.log('No #cdmOptions, so use alternative');
			//vError('No dialogs section found.\nCan not attach errorWindow');
		else {
			dialogs.append('<div id="errorWindow" title="ERROR">'+
				    '<p>An error has occured:</p>'+
				    '<p id="errorMsg"></p>'+ 
					'</div> ');
		}
	};
	// next attach the handler, that shows an error-msg and wait for oke
    $("#errorWindow").dialog({autoOpen: false,
                    width: 450,
                    modal: true,
                    closeText: 'Annuleer',
                    open: function() {
                      try {
                          var dialogPrefix = '#errorWindow ';

                         // set information items at top of box.
                         var errorMsg = $(this).data('errorMsg');
                         $(dialogPrefix+'#errorMsg').html( errorMsg );

                         return;
                       } catch (err) {
                               showError('Error during "Open error-window":', err);
                       }

                     },
                     buttons: {
                         "OK": function() {
                             $(this).dialog('close');
                             return;
                         }
                     }
                });  // END of errorWindow


});
