#!/bin/sh

echo "the file extends the cdp by adding jars needed for CDM"
echo "after execution of this script you need to restart the tomcat-pentaho server"
echo " Ensure that system/cdp is installed first, otherwise this install might fail"

cp  cdp-lib-extension/* ../cdp/lib/


