

/*
 *  define some globals that will be exposed to cde and will be connected to the interface there.
 */
var srcBox, srcFv, dstBox, dstFv;

//  trigger used to refresh the boxes
var refreshLogs = 1;

// trigger to fill the difference table
var fillDifferenceTable = 1;
var diffViewDiv = '#diffViewDiv';
function getDifferences() {
    $('#diffSrc').text(srcBox.txt);
    Dashboards.fireChange('fillDifferenceTable', fillDifferenceTable+1);
    $(diffViewDiv).show();
    return;
};

function readyDifferences() {
    $(diffViewDiv).hide();
    return;
}


/*  outdated code that patches a html-string directly into a targetDiv
   Now using CDE component (and cdp as a json-datasource)
function updateTable(tblSel, srcSel, targetDiv) {
	  var pars = {accessId: 'showTable',
			       tblSel: tblSel,
			   		source: srcSel};
	  cdpExec(pars, function(data, s) {
		  				if (data.length > 1)
		  					alert('can only handle first element. Discarding'+data.slice(1));
		  				var data = data[0];  // take first element
		  				$(targetDiv).html(data);
		      }, true);
	};
*/
	function updateLogTables(srcSel) {
	  /*
	    update log-table and error-table
	   */
	//  alert('running updates'+srcSel);
//	  updateTable('actions', srcSel, '#actionDiv');
//	  updateTable('errors', srcSel, '#errorDiv');
      
      Dashboards.fireChange('refreshLogs', refreshLogs+1);
      // set the text-boxes
      $('#currSrc1').text(srcSel);
      $('#currSrc2').text(srcSel);
	};

	/*
	 *  Routines to ask for a destination and complete a command.
	 */
	var partialCommand = null;  // used to store command that still needs a destination via the 'destPopup' window 

	function ask_dest_run_action (action) {
		// prepare a partial command
	  partialCommand = 	action;
	  // and popup the window to get a destination (ok-button will proceed, cancel will clear the partialCommand.
	  $('.destPopup').show();
	  return;
	}
	function dst_ok_button () { 
	    dstFv.accept();
	    // finish the partial command
		if (partialCommand == null) {
			alert(" STRANGE!! no command available");
			return;
		}
		run_action_full (partialCommand, srcBox.getValue(), dstBox.getValue(), msg);
		partialCommand = null;
	    $('.destPopup').hide();
	    return;};

   function dst_cancel_button () { 
	    dstFv.reject();
	    partialCommand = null;  // operation cancelled
	    $('.destPopup').hide();
	    return;
	};
	


 


/*
  Below are the interface functions that collect the parameters and
  call the cdP-engine for handling the actual data-processing.
  (implementation of the dashboard buttons)
*/

	
function run_action_full (action, src, dsts, msg) {
		    var pars = {accessId: 'process-jsonMgt-command',
		                  action: action,
		                  user: getCurrentUser(),
		                  source: src,
		                  destinations: dsts,
		                  msg: msg  };
		                                            
		    cdpExec(pars, function (d, s) {
		    	                            if (d.length > 0)
		    	                            	alert(d);
		                                    updateLogTables(srcBox.getValue());  //() added
		                                });
		   return;
		};

	
function run_action (action) {
	var msg = ( arguments[1] ) ? arguments[1] : "";
	run_action_full (action, "", "", msg);
	return;
	};
	

var noWildCardsAllowed = { create: true,
 		    "clean-copy": true,
                    'checkout-copy-last': true};

function checkedSrc(action) {
  // checks whether src is valid for the given 'action'
  // currently only checks for wild-cards
        var src = srcBox.getValue();
        if (   (noWildCardsAllowed[action])
            && (/\*/.exec(src))) {
          alert('No wildcards (*) allowed in source of action: '+action);
	   return false;
        } else
           return true;
};
	
function run_action_src (action) {
	var msg = ( arguments[1] ) ? arguments[1] : "";
        var src = srcBox.getValue();
        if ( checkedSrc(action) ) 
	  run_action_full (action, src, "", msg);
   return;
};

function helpFunc () 
{
    var pars = {accessId: 'process-jsonMgt-command',
                  action: "help",
                  user: getCurrentUser(),
                  source: "",
                  destinations: "",
                  msg: ""  };
                                            
    cdpExec(pars, function (d, s) {
                                    Dashboards.fireChange('refreshLogs', refreshLogs+1);
                                    alert(d[0]);
                                });

   return;
}

$(function () {

    // hide the differences diff (until needed)
    readyDifferences()
    
	// Get the commit-message and add a commit
	$("#commitDialog").dialog({autoOpen: false,
                    width: 450,
                    modal: true,
                    closeText: 'Annuleer',
                    open: function() {
                      try {
                    	  var dialogPrefix = '#commitDialog ';
                         // set information items at top of box.
                         $(dialogPrefix+'#filemask').html('<strong>files</strong>: '+srcBox.getValue());
                         
                         // set the dialog-defaults
                         $(dialogPrefix+'#msg').val('');

                         return;
                       } catch (err) {
                               showError('Error during "Open commit-dialog":', err);
                       }

                     },
                     buttons: {
                         "Commit": function() {
                           try {
                               var dialogPrefix = '#commitDialog ';
 
                               var msg = $(dialogPrefix+'#msg').val();

                               run_action_src('commit', msg);
   alert('returned from tun_action_sr. Now close commitDialog');
                             
                               //$(this).dialog('close');
			       // previous function replaced to allow for
 				// external submithandler to call this function.
			       $(dialogPrefix).dialog('close');
                             return;
                           } catch (err) {
                               showError('Error during "Commit":', err);
                           }
                         }
                     }
 		}).submit(function () {
              alert('Now calling the original commit. Return false afterwards.')
              $('#commitDialog ').dialog('option', 'buttons').Commit()
 	      return false;   // prevent default behavior.
           });  // END of commitDialog




	// Get the commit-message and add a commit
	$("#duplicTrackDialog").dialog({autoOpen: false,
                    width: 450,
                    modal: true,
                    closeText: 'Annuleer',
                    open: function() {
                      try {
                    	  var dialogPrefix = '#duplicTrackDialog ';
                         // set information items at top of box.
                         $(dialogPrefix+'#src').html(srcBox.getValue());
                         
                         // set the dialog-defaults
                         $(dialogPrefix+'#dst').val('');

                         return;
                       } catch (err) {
                               showError('Error during "Open duplicTrack-dialog":', err);
                       }

                     },
                     buttons: {
                         "Duplicate": function() {
                           try {
                               var dialogPrefix = '#duplicTrackDialog ';
 
                               var dst = $(dialogPrefix+'#dst').val();

                               run_action_full ('clean-copy', srcBox.getValue(), dst, "");
                             
                               $(this).dialog('close');
                             return;
                           } catch (err) {
                               showError('Error during "duplicTrack" dialog:', err);
                           }
                         }
                     }
 		});  // END of duplicTrack dialog
	
	
	
	// Get the commit-message and add a commit
	$("#errorWindow").dialog({autoOpen: false,
                    width: 450,
                    modal: true,
                    closeText: 'Annuleer',
                    open: function() {
                      try {
                    	  var dialogPrefix = '#errorWindow ';

                         // set information items at top of box.
                    	 var errorMsg = $(this).data('errorMsg')
                         $(dialogPrefix+'#errorMsg').html( errorMsg );

                         return;
                       } catch (err) {
                               showError('Error during "Open error-window":', err);
                       }

                     },
                     buttons: {
                         "OK": function() {
                             $(this).dialog('close');
                             return;
                         }
                     }
 		});  // END of errorWindow
                        	
});  // END of dialog handlers
/*
 end interface functions  (implementations of the different buttons.)
*/






function createSelectBox(targetDiv) {
    return {
      obj: $(targetDiv),
      txt: '',
      setValue: function(newTxt) {
	  this.txt = newTxt;
	  this.obj.text(this.txt);
	  return;},
      getValue: function() { return this.txt;}
    };
};



function createFileViewer(targetDiv, selBox, updateFunc) {
 //   var updateFunc1 = (typeof (updateFunc) == 'function')?
//	              updateFunc : function(x) {return null;};
    return {
	selectBox: selBox,
	update: (typeof (updateFunc) == 'function')?
	         updateFunc : function(x) {return null;},
	container: $(targetDiv),
	selectStr: selBox.txt,
	selectMap: {},
	show: function() {this.container.show();},
	hide: function() {this.container.hide();},
	init: function() {
	    this.oldSelect = this.selectBox.txt;
	    this.selectStr = '';
	    this.selectMap = {};
	    this.selectBox.setValue(this.selectStr);
	    this.show();
	},
	addFile: function(fname) {
	    if (this.selectMap[fname] == undefined) {
		this.selectStr += ' '+fname;
		this.selectBox.setValue(this.selectStr);
	      }
	    else {
		alert('file: '+fname+' is already selected');
	    }
	},
	accept: function() {
	    delete this.oldSelect;
	    this.hide();
	    //alert('CvK: update for: '+this.selectBox.txt)
	    this.update(this.selectBox.txt);},
	reject: function() {
	    this.selectBox.setValue(this.oldSelect);
	    delete this.oldSelect;
	    this.hide(); }

    };
};





/*
 *   After pageload initialize_step1 is called to retrieve the document root (location of pentaho-solution in the file-system).
 *   When the docroot is returned the intialize_step2 will be called with the docRoot
 */
$(function () {
   // initialize_step_1
    var pars = {accessId: 'initialize'};
	cdpExec(pars, initialize_step_2);
	return;	
});

function initialize_step_2 () {
    var pars = {accessId: 'jqGetDocRoot'};
	cdpExec(pars, initialize_step_3);
	return;	
};


function initialize_step_3 (result, status) {

  var docRoot = result[0];
  var cdpBase="/pentaho/content/cdp/exec?"+theCdpFile;
  /*
    prepare the file-selector for the source(s)
  */
  srcBox = createSelectBox('#srcBoxDiv');
  srcBox.setValue('*');
  srcFv = createFileViewer("#srcFileviewWindow", srcBox, updateLogTables);
  /*  initialization of buttons is performed in a call-back of the create-fileTreeRootContainer
      (see below) as the file-root first needs to be loaded. */
  srcFv.hide();
//  $('#src-sel-button')[0].onclick = function(event) { srcFv.init() };
//  $("#sfv-ok-button")[0].onclick = function(event) { srcFv.accept();};
//  $("#sfv-cancel-button")[0].onclick = function(event) { srcFv.reject();};

  /*
    prepare the file-selector for the destination(s)
  */
  dstBox = createSelectBox('#dstBoxDiv');
  dstFv = createFileViewer("#dstFileviewwindow", dstBox);
  /*  initialization of buttons is performed in a call-back of the create-fileTreeRootContainer
      (see below) as the file-root first needs to be loaded. */
  dstFv.hide();
  //  $('#dst-sel-button')[0].onclick = function(event) { dstFv.init() };
  //  $("#dfv-ok-button")[0].onclick = function(event) { dstFv.accept();};
  // $("#dfv-cancel-button")[0].onclick = function(event) { dstFv.reject();};

	    // Finish preparations of the source(s) file-viewer when root is available.
  $('#srcFileviewDiv').fileTree({root:  docRoot,
	                        script: cdpBase,
	                        skeleton: {accessId: 'genFileView'}}, 
                      function(file) { srcFv.addFile(file); });
	    // Finish preparations of the destinations(s) file-viewer when root is available.
  $('#dstFileviewDiv').fileTree({root:  docRoot,
	                        script: cdpBase,
	                        skeleton: {accessId: 'genFileView'}}, 
		     function(file) { dstFv.addFile(file);});

  /*
    Function that retrieves a destination-selection for commands
    that use a destination. For other commands the an empty string is returned.
  */
  var destPopup = $(".destPopup");
  destPopup.hide();
  
  


    /*
      update log-table and error-table
    */
    updateLogTables(srcBox.getValue());
   }

