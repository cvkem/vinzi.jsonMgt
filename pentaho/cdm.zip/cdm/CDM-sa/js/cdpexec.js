/**** 
   This file contains the code to make the CDE compatible with cdp.
   This compatibility implies that cdp-datasources can act as 
   cda datasources and therefore be used as datasource for other 
   other cde-components just like the existing cda datasources.
   
   The first part of this code contains the cdpExec function which is
   only a utility function to allow direct calls to the cdp-system, 
   without running via cda.

   Next we have the function setQueryWithCdp. This function introduces
      1. A utility function derive the cdp-file-name from the
         name of the dashboard (using same name as the .cdfde file)
      2. A replacement of the Query object from Dashboards.js (based on
         development branch of January 3 2013. There are 2-3 small 
 	 patches to the original code, which are clearly marked
        with  / *  CDP-patch  *  /, followed by the original code in
        comments.

   NOTE:
   In the current implementation you have to define a fake datasource with 
   the same name in the datasources section, otherwise CDE assumes that
   the datasource does not exist and does not perform any calls to
   the Query object.
   NOTE:
   The calls to vWarn() are included as pvc.log does not produce output. 
   These calls can be omitted.
*****/


/********
The cdpExec function is used to do directly trigger calls to the cdp.
If you want to use the returned data in a component you should not use this
function but route the calls via the cda-interface.
*****/ 
function cdpExec(pars, updateFunc /* , acceptError*/) {
    var acceptError = (arguments.length > 2) ? arguments[2] : false;
    
    if ((typeof theCdpFile !== 'string') || (theCdpFile.length == 0))
        console.log("expected to receive string 'cdpFile'. Received: "+theCdpFile);
    var base="/pentaho/content/cdp/exec?"+theCdpFile;

//    alert ('Going to call  CDP with parameters: '+ strObj(pars));

    var jqXhr = $.post(base, pars, function (data, status) {
//      alert('received status='+status+'\n and data='+data);
        updateFunc(data, status)})
        // add an error-handler to the deferred object
        .error(function(xhr) {
                if (! (acceptError == true)) {
                  var errWin = $('#errorWindow');
              errWin.data('errorMsg', xhr.responseText);
              errWin.dialog('open');
                }
            /*
                alert("An error occurred during the processin of the command with parameters:\n"+
                              strObj(pars)+
                              "\n status="+xhr.status+
                              "\n responsetext="+xhr.responseText); */
                });
//    Dashboards.fireChange('refresh',2);
    return;
};



